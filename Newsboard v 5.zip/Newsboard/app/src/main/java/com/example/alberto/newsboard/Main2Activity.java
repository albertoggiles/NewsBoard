package com.example.alberto.newsboard;


import android.content.Intent;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;


import android.widget.ListView;


import java.util.ArrayList;

/**
 * Submenu de usuario
 */



public class Main2Activity extends AppCompatActivity {
    boolean click = false;
    private ListView lv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        /**
         * Ocultar la action bar
         */
        getSupportActionBar().hide();

        /**
         * Creacion del objeto de la clase Basedatos y conexion a esta misma
         */
        final Basedatos objeto = new Basedatos(this);
        Basedatos admin = new Basedatos(this);
        final SQLiteDatabase db = admin.getWritableDatabase();

        final Button periodicos=(Button) findViewById(R.id.periodico);
        final Button deportes=(Button) findViewById(R.id.deporte);
        final Button juegos=(Button) findViewById(R.id.juego);
        final Button refresh=(Button) findViewById(R.id.refreshfav);

        /**
         *  Boton de refresco de la activity para mostrar cambios en basedatos
         */
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
                startActivity(getIntent());


            }
        });


        /**
         * Botones para acceder a la activity, reservada a la respectiva categoría
         */
        juegos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    Intent sesion = new Intent (v.getContext(), GameActivity.class);
                    startActivity(sesion);


            }
        });

        periodicos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sesion = new Intent (v.getContext(), PeriodicoActivity.class);
                startActivity(sesion);

            }
        });

        deportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sesion = new Intent (v.getContext(), SportsActivity.class);
                startActivity(sesion);


            }
        });


        /**
         * Listview que muestra las revistas o periodicos que el usuario tenga como favoritas
         */
        lv1 = (ListView)findViewById(R.id.sq);
        ArrayList<String> favs = new ArrayList<>();

        Cursor fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario +"' )", null);
        if(fila.moveToFirst()){
            do{
                favs.add(fila.getString(0) + " - " + fila.getString(1));
            }while(fila.moveToNext());
        }
        db.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, favs);
        lv1.setAdapter(adapter);


    }





}
