package com.example.alberto.newsboard;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import es.dmoral.toasty.Toasty;

// Actividad reservada a las noticias de deportes

public class SportsActivity extends AppCompatActivity {

    private Cursor fila;
    String usua;
    String newss;
    boolean click = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports);

        // Ocultar la action bar
        getSupportActionBar().hide();

        // Creacion del objeto de la clase Basedatos y conexion a esta misma
        final Basedatos objeto = new Basedatos(this);
        Basedatos admin = new Basedatos(this);
        final SQLiteDatabase db = admin.getWritableDatabase();


        // Boton para acceder a la url de la respectiva revista
        final Button marcaa=(Button) findViewById(R.id.marca);
        marcaa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x= "marca";

                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);
            }
        });

        final Button das=(Button) findViewById(R.id.as);
        das.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="as";
                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button onee=(Button) findViewById(R.id.one);
        onee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="one";
                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button marcadoress=(Button) findViewById(R.id.marcadores);
        marcadoress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="marcadores";
                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });



        // Boton para añadir o eliminar de favoritos
        final Button favas=(Button) findViewById(R.id.staras);
        favas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="as" ;

                // Animacion rotativa del boton de fav
                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }



                // Comprobación de si ya está en favoritos, si no lo está lo añade y si ya estaba en favoritos lo borra

                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    // Refresco de activity para que al borrar un registro de fav se actualice
                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }


            }
        });

        final Button favone=(Button) findViewById(R.id.starone);
        favone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="onefootball" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }



            }
        });

        final Button favmarca=(Button) findViewById(R.id.starmarca);
        favmarca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="marca" ;


                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }




            }
        });

        final Button favmarcadores=(Button) findViewById(R.id.starmarcadores);
        favmarcadores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="marcadores" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);


                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }



            }
        });


    }
}