package com.example.alberto.newsboard;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import es.dmoral.toasty.Toasty;

/**
 * Actividad reservada a las noticias de los periodicos
 */

public class PeriodicoActivity extends AppCompatActivity {
    private Cursor fila;
    String usua;
    String newss;
    boolean click = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_periodico);

        /**
         * Ocultar la action bar
         */
        getSupportActionBar().hide();

        /**
         * Ocultar la action bar
         */
        final Basedatos objeto = new Basedatos(this);
        Basedatos admin = new Basedatos(this);
        final SQLiteDatabase db = admin.getWritableDatabase();


        /**
         * Boton para acceder a la url del respectivo periodico
         */
        final Button paiss=(Button) findViewById(R.id.pais);
        paiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x= "elpais";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);
            }
        });

        final Button minutoss=(Button) findViewById(R.id.minutos);
        minutoss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="minutos";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button serr=(Button) findViewById(R.id.ser);
        serr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="ser";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button diarioo=(Button) findViewById(R.id.diario);
        diarioo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="diario";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });


        /**
         *  Boton para añadir o eliminar de favoritos
         */
        final Button fav20=(Button) findViewById(R.id.star20);
        fav20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="20minutos" ;

                /**
                 * Animacion rotativa del boton de fav
                 */
                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }


                /**
                 * Comprobación de si ya está en favoritos, si no lo está lo añade y si ya estaba en favoritos lo borra
                 */

                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    /**
                     * Refresco de activity para que al borrar un registro de fav se actualice
                     */
                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }

            }
        });

        final Button favser=(Button) findViewById(R.id.starser);
        favser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = MainActivity.usuario;
                String news = "ser";

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }

            }
        });

        final Button favdia=(Button) findViewById(R.id.stardia);
        favdia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="eldiario" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }

            }
        });

        final Button favpais=(Button) findViewById(R.id.starpais);
        favpais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name =MainActivity.usuario;
                String news ="elpais" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Eliminado de favoritos!", Toast.LENGTH_SHORT, true).show();

                    objeto.borrarfav(name, news);

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(R.anim.zoom_forward_in, R.anim.zoom_forward_out);

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }


            }
        });


    }
}