package com.example.alberto.newsboard;

/**

 * @author

 */

// Activity dedicada al registro e iniciar sesion

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.*;
import android.content.Intent;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity {
    static EditText et1,et2;
    private Cursor fila;
    String usua;
    String pass;
    static String usuario;
    String contrasena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Ocultar la action bar
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button login1 = (Button) findViewById(R.id.login);
        final Button signin1 = (Button) findViewById(R.id.signin);


        final Context context = getApplicationContext();

        // Creacion del objeto de la clase Basedatos y conexion a esta misma
        final Basedatos objeto = new Basedatos(this);
        Basedatos admin = new Basedatos(this);
        final SQLiteDatabase db = admin.getWritableDatabase();

        et1 = (EditText) findViewById(R.id.user);
        et2 = (EditText) findViewById(R.id.password);




        // Boton del login
        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usuario = et1.getText().toString();
                contrasena = et2.getText().toString();




                // Comprobación de la combinacion entre contraseña y usuario

                fila = db.rawQuery("SELECT name, pass FROM tabla WHERE (name='"+ usuario + "' and pass='" + contrasena + "' )", null);


                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    pass = fila.getString(1);

                }
                if (usuario.equals(usua) && contrasena.equals(pass)) {
                    Intent sesion = new Intent(v.getContext(), Main2Activity.class);
                    startActivity(sesion);
                    et1.setText("");
                    et2.setText("");
                }else{

                    // Animación shake del boton
                    Animation shake = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake);
                    v.startAnimation(shake);

                    Toasty.error(getApplicationContext(), "Usuario y/o contraseña incorrectos", Toast.LENGTH_SHORT, true).show();

                }
            }
        });

        //Boton del sign in
        signin1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                usuario = et1.getText().toString();
                String name = et1.getText().toString();
                String pass = et2.getText().toString();

                // Comprobación de si el usuario esta registrado ys
                fila = db.rawQuery("SELECT name FROM tabla WHERE (name='"+ usuario + "')", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);}

                if(usuario.equals(usua)) {

                    Animation shake = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake);
                    v.startAnimation(shake);
                    Toasty.warning(getApplicationContext(), "Usuario ya existente", Toast.LENGTH_SHORT, true).show();

                }else {
                    objeto.guardar(name, pass);
                    Intent sesion = new Intent(v.getContext(), RegistroActivity.class);
                    startActivity(sesion);
                }
        }

    });
    }
}



