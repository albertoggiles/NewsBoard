package com.example.alberto.newsboard;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.Button;
import android.widget.Toast;

import es.dmoral.toasty.Toasty;

public class GameActivity extends AppCompatActivity {
    private Cursor fila;
    String usua;
    String newss;
    boolean click = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        final Basedatos objeto = new Basedatos(this);

        getSupportActionBar().hide();
        Basedatos admin = new Basedatos(this);
        final SQLiteDatabase db = admin.getWritableDatabase();


        final Button hobbyy=(Button) findViewById(R.id.hobby);
        hobbyy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x= "hobby";

                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);
            }
        });

        final Button djuegoss=(Button) findViewById(R.id.djuegos);
        djuegoss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="djuegos";
                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button meristationn=(Button) findViewById(R.id.meristation);
        meristationn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="meristation";
                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button vandall=(Button) findViewById(R.id.vandal);
        vandall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="vandal";
                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button favvandal=(Button) findViewById(R.id.starvan);
        favvandal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="vandal" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }




                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Ya esta añadido a favoritos", Toast.LENGTH_SHORT, true).show();

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }


            }
        });

        final Button favmeri=(Button) findViewById(R.id.starmeri);
        favmeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="meristation" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }



                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Ya esta añadido a favoritos", Toast.LENGTH_SHORT, true).show();

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }

                Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();

            }
        });

        final Button fav3d=(Button) findViewById(R.id.star3d);
        fav3d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="3djuegos" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }



                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Ya esta añadido a favoritos", Toast.LENGTH_SHORT, true).show();

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }

            }
        });

        final Button favhobb=(Button) findViewById(R.id.starhobb);
        favhobb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name =MainActivity.usuario;
                String news ="hobbyconsolas" ;

                click = !click;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Interpolator interpolador = AnimationUtils.loadInterpolator(getBaseContext(),
                            android.R.interpolator.fast_out_slow_in);

                    v.animate()

                            .rotation(click ? 1080f : 0)
                            .setInterpolator(interpolador).setDuration(2000)
                            .start();

                }


                fila = db.rawQuery("SELECT name, news FROM fav WHERE (name='"+ MainActivity.usuario + "' and news='" + news + "' )", null);

                if (fila.moveToFirst() == true) {
                    usua = fila.getString(0);
                    newss = fila.getString(1);
                }

                if(MainActivity.usuario.equals(usua)&& news.equals(newss)) {
                    Toasty.warning(getApplicationContext(), "Ya esta añadido a favoritos", Toast.LENGTH_SHORT, true).show();

                }else {


                    objeto.fav(name, news);

                    Toasty.success(getApplicationContext(), "Añadido a favoritos!", Toast.LENGTH_SHORT, true).show();
                }



            }
        });


    }
}
