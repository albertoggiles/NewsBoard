package com.example.alberto.newsboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PeriodicoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_periodico);

        getSupportActionBar().hide();

        final Button paiss=(Button) findViewById(R.id.pais);
        paiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x= "elpais";

                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);
            }
        });

        final Button minutoss=(Button) findViewById(R.id.minutos);
        minutoss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="minutos";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button serr=(Button) findViewById(R.id.ser);
        serr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="ser";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button diarioo=(Button) findViewById(R.id.diario);
        diarioo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="diario";
                Intent i = new Intent (PeriodicoActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });


    }
}
