package com.example.alberto.newsboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        getSupportActionBar().hide();

        final Button hobbyy=(Button) findViewById(R.id.hobby);
        hobbyy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x= "hobby";

                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);
            }
        });

        final Button djuegoss=(Button) findViewById(R.id.djuegos);
        djuegoss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="djuegos";
                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button meristationn=(Button) findViewById(R.id.meristation);
        meristationn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="meristation";
                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button vandall=(Button) findViewById(R.id.vandal);
        vandall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="vandal";
                Intent i = new Intent (GameActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });


    }
}
