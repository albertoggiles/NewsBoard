package com.example.alberto.newsboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SportsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports);

        getSupportActionBar().hide();

        final Button marcaa=(Button) findViewById(R.id.marca);
        marcaa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x= "marca";

                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);
            }
        });

        final Button das=(Button) findViewById(R.id.as);
        das.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="as";
                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button onee=(Button) findViewById(R.id.one);
        onee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="one";
                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });

        final Button marcadoress=(Button) findViewById(R.id.marcadores);
        marcadoress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String x="marcadores";
                Intent i = new Intent (SportsActivity.this, web.class);
                i.putExtra("var", x);
                startActivity(i);

            }
        });


    }
}