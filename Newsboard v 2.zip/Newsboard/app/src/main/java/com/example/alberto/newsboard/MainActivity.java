package com.example.alberto.newsboard;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final String userx="alberto";
        final String passwordx="12345";
        final Button login1=(Button) findViewById(R.id.login);
        final Button signin1=(Button) findViewById(R.id.signin);
        final EditText usuario=(EditText) findViewById(R.id.user);
        final EditText contraseña=(EditText) findViewById(R.id.password);

       final Context context= getApplicationContext();



        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(usuario.getText().toString().equals(userx) && contraseña.getText().toString().equals(passwordx) ){
                    Intent sesion = new Intent (v.getContext(), Main2Activity.class);
                    startActivity(sesion);

                }

            }
        });

        signin1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre= usuario.getText().toString();
                String contrasena= contraseña.getText().toString();
                Basedatos objeto= new Basedatos(context);
                objeto.guardar(nombre, contrasena);
            }
        });


    }
}
