package com.example.alberto.newsboard;



import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Vector;

//Clase encargada de crear o actualizar la BD si es necesario.
public class Basedatos extends SQLiteOpenHelper {
    public Basedatos(Context context){
        super(context, "base_de_datos", null, 1);
    }

    //Método que se ejecuta si la BD no está creada.
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE tabla ("+"nombre TEXT PRIMARY KEY AUTOINCREMENT, contrasena TEXT)");
    }

    //Método que se ejecuta si ha habido alguna modificación en la BD.
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newerVersion){

    }

    //Método con el que vamos a realizar una inserción de un registro de la tabla "tabla" pasándole 3 parámetros.
    public void guardar(String nombre, String contrasena){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO tabla VALUES(null, "+"'"+nombre+"', "+contrasena + ")");

    }
}
