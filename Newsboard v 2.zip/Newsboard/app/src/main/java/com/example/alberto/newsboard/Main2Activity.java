package com.example.alberto.newsboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().hide();

        final Button periodicos=(Button) findViewById(R.id.periodico);
        final Button deportes=(Button) findViewById(R.id.deporte);
        final Button juegos=(Button) findViewById(R.id.juego);


        juegos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    Intent sesion = new Intent (v.getContext(), GameActivity.class);
                    startActivity(sesion);


            }
        });

        periodicos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sesion = new Intent (v.getContext(), PeriodicoActivity.class);
                startActivity(sesion);

            }
        });

        deportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sesion = new Intent (v.getContext(), SportsActivity.class);
                startActivity(sesion);

            }
        });


    }
}
