package com.example.alberto.newsboard;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


//Clase encargada de crear o actualizar la BD si es necesario.
public class Basedatos extends SQLiteOpenHelper {
    public Basedatos(Context context){
        super(context, "base_de_datos", null, 1);
    }

    //Método que se ejecuta si la BD no está creada.
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE tabla ("+"name TEXT PRIMARY KEY, pass TEXT)");
        db.execSQL("CREATE TABLE fav ("+"name TEXT, news TEXT)");

    }

    //Método que se ejecuta si ha habido alguna modificación en la BD.
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newerVersion){
    }

    //Método con el que vamos a realizar una inserción de un registro de la tabla "tabla" pasándole 2 parámetros.
    public void guardar (String name2, String pass2){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO tabla VALUES('"+name2+"', '"+pass2+"')");


    }

    //Método para agregar un registro a la tabla fav
    public void fav (String name2, String news2){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO fav VALUES('"+name2+"', '"+news2+"')");


    }

    //Método para eliminar un registro de la tabla fav
    public void borrarfav (String name2, String news2){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM fav WHERE name = '"+name2+"' AND news =  '"+news2+"' ");


    }



}
