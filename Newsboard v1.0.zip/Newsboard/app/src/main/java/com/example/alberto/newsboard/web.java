package com.example.alberto.newsboard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class web extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        WebView myWebView = (WebView) findViewById(R.id.webb);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        myWebView.setWebViewClient(new WebViewClient());

        Bundle extras = getIntent().getExtras();
        String var = extras.getString("var");


    if(var.equals("hobby")) {
        myWebView.loadUrl("https://www.hobbyconsolas.com/");
    }

    if(var.equals("djuegos")) {
            myWebView.loadUrl("https://www.3djuegos.com/");
    }

    if(var.equals("meristation")) {
            myWebView.loadUrl("https://as.com/meristation/");
    }

    if(var.equals("vandal")) {
            myWebView.loadUrl("https://vandal.elespanol.com/");
    }

    if(var.equals("minutos")) {
            myWebView.loadUrl("https://www.20minutos.es/");
    }

    if(var.equals("elpais")) {
            myWebView.loadUrl("https://elpais.com/");
    }

    if(var.equals("ser")) {
            myWebView.loadUrl("http://cadenaser.com/");
    }

    if(var.equals("diario")) {
            myWebView.loadUrl("https://www.eldiario.es/");
    }

    if(var.equals("marca")) {
            myWebView.loadUrl("http://www.marca.com/");
    }

    if(var.equals("as")) {
            myWebView.loadUrl("https://as.com/");
    }

    if(var.equals("one")) {
            myWebView.loadUrl("https://onefootball.com/es/inicio");
    }

    if(var.equals("marcadores")) {
            myWebView.loadUrl("https://www.mismarcadores.com/");
    }

    }
}
